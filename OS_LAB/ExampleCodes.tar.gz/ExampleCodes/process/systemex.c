//
// Created by Meraj
// on 10/31/17.
//
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main() {
    int a = 2;
    fork();
    sprintf()
    return return_value;
}
